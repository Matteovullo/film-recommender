let charts = {};

// URL API Gateway
let API_BASE_URL = 'https://g1q9d4xdfg.execute-api.eu-west-1.amazonaws.com/Prod';

async function loadAnalytics() {
    showLoading();
    
    try {
        const response = await fetch(API_BASE_URL + '/api/analytics', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('cognitoToken')}`
            }
        });
        
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        
        const data = await response.json();
        console.log('📊 Dati analytics Lambda:', data);
        
        if (data.status === 'success') {
            displayRealData(data);
        } else {
            displayNoData('Nessun dato analytics disponibile');
        }
        
        await loadSQSStats();
        updateLastUpdated();
        
    } catch (error) {
        console.error('❌ Errore caricamento analytics:', error);
        displayError('Errore di connessione: ' + error.message);
    }
}

async function loadSQSStats() {
    try {
        const response = await fetch('/worker/process', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('cognitoToken')}`
            }
        });
        
        if (response.ok) {
            const result = await response.json();
            displaySQSInfo(result);
        }
    } catch (error) {
        console.log('ℹ️ SQS non disponibile');
    }
}

function displaySQSInfo(sqsData) {
    const sqsInfoDiv = document.getElementById('sqsInfo') || createSQSInfoDiv();
    
    sqsInfoDiv.innerHTML = `
        <div class="info-card" style="background:#f0f8ff; border-left:4px solid #3498db;">
            <h4>🔵 SQS Worker Attivo</h4>
            <p><strong>Elaborati:</strong> ${sqsData.processed} messaggi</p>
            <p><strong>Stato:</strong> ${sqsData.status}</p>
            <p><strong>Architettura:</strong> EB + SQS + Lambda</p>
        </div>
    `;
}

function createSQSInfoDiv() {
    const div = document.createElement('div');
    div.id = 'sqsInfo';
    document.querySelector('.dashboard').appendChild(div);
    return div;
}

function displayRealData(data) {
    updateDataStatus('Dati REALI Lambda + DynamoDB', 'status-real');
    displayStats(data.metrics);
    displayInsights(data.insights || []);
}

function displayStats(metrics) {
    const statsGrid = document.getElementById('statsGrid');
    
    statsGrid.innerHTML = `
        <div class="stat-card">
            <div class="stat-number">${metrics.total_recommendations || 0}</div>
            <div class="stat-label">Raccomandazioni Totali</div>
            <div class="stat-subtitle">⚡ Lambda</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">${metrics.unique_users || 1}</div>
            <div class="stat-label">Utenti Unici</div>
            <div class="stat-subtitle">🔐 Cognito</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">${metrics.success_rate || 95}%</div>
            <div class="stat-label">Tasso di Successo</div>
            <div class="stat-subtitle">🚀 API Gateway</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">${metrics.avg_response_time || 0.8}s</div>
            <div class="stat-label">Tempo Risposta</div>
            <div class="stat-subtitle">💨 Performant</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" style="font-size:1.6em;">${metrics.most_popular_genre || 'Sci-Fi'}</div>
            <div class="stat-label">Genere Popolare</div>
            <div class="stat-subtitle">📈 Analytics</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" style="font-size:1.6em;">Lambda</div>
            <div class="stat-label">Compute</div>
            <div class="stat-subtitle">💵 ~$1/mese</div>
        </div>
    `;
}

function displayInsights(insights) {
    const insightsGrid = document.getElementById('insightsGrid');
    
    if (insights && insights.length > 0) {
        insightsGrid.innerHTML = insights.map(insight => `
            <div class="insight-card">
                <div>💡 ${insight}</div>
            </div>
        `).join('');
    } else {
        insightsGrid.innerHTML = `
            <div class="insight-card">
                <div>🚀 Architettura Serverless Attiva</div>
            </div>
            <div class="insight-card">
                <div>⚡ API Gateway + Lambda</div>
            </div>
            <div class="insight-card">
                <div>💰 Costo totale: ~$8/mese</div>
            </div>
        `;
    }
}

function showLoading() {
    document.getElementById('statsGrid').innerHTML = '<div class="loading">Caricamento dati Lambda...</div>';
    updateDataStatus('Caricamento...', 'status-no-data');
}

function updateDataStatus(text, className) {
    const statusEl = document.getElementById('dataStatus');
    statusEl.textContent = text;
    statusEl.className = 'data-status ' + className;
}

function updateLastUpdated() {
    const now = new Date();
    document.getElementById('lastUpdated').textContent = `Ultimo aggiornamento: ${now.toLocaleString('it-IT')}`;
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('📊 Dashboard Lambda inizializzata');
    
    const savedUser = localStorage.getItem('cognitoUser');
    if (savedUser) {
        document.getElementById('currentUser').textContent = savedUser;
    }
    
    loadAnalytics();
    
    setInterval(loadAnalytics, 30000);
});
