from flask import Flask, render_template, jsonify
import boto3
import json
import logging
import os
from datetime import datetime, timedelta

# Inizializza Flask con un nome di modulo esplicito per Gunicorn
app = Flask('application', static_folder='static', template_folder='static/html')
app.secret_key = 'film-recommender-docker-2024'

logging.basicConfig(level=logging.INFO)
# Configura il logger per integrarsi con l'output di Gunicorn in produzione
logger = logging.getLogger('gunicorn.error') 

# Variabili di configurazione AWS
ANALYTICS_TABLE = 'FilmRecommender-Analytics'
SQS_QUEUE = 'film-recommender-analytics'

# Inizializzazione Boto3 spostata all'interno di una funzione per prevenire il crash all'avvio
dynamodb = None
sqs = None
def init_aws_clients():
    global dynamodb, sqs
    if dynamodb is None or sqs is None:
        try:
            dynamodb = boto3.resource('dynamodb', region_name='eu-west-1')
            sqs = boto3.client('sqs', region_name='eu-west-1')
        except Exception as e:
            logger.error(f"Errore di inizializzazione Boto3 (IAM/SDK): {e}")

@app.before_request
def check_aws_clients():
    init_aws_clients()
    
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/app')
def app_page():
    return render_template('app.html')

@app.route('/dashboard')
def dashboard():
    return render_template('analytics_dashboard.html')

# Endpoints Worker
@app.route('/worker/health')
def worker_health():
    # Questo endpoint non dipende da Boto3 e dovrebbe sempre funzionare
    return jsonify({
        'status': 'healthy', 
        'service': 'EB Docker + SQS Worker', 
        'timestamp': datetime.now().isoformat(),
        'architecture': 'Docker on Elastic Beanstalk'
    })

@app.route('/worker/process')
def process_queue():
    if sqs is None or dynamodb is None:
        return jsonify({'error': 'Servizi AWS non inizializzati (IAM Error)'}), 500
    processed = process_sqs_messages()
    return jsonify({
        'processed': processed, 
        'status': 'success', 
        'timestamp': datetime.now().isoformat()
    })

@app.route('/worker/stats')
def worker_stats():
    if sqs is None:
        return jsonify({'error': 'Servizi AWS non inizializzati (IAM Error)'}), 500
        
    try:
        queue_url = sqs.get_queue_url(QueueName=SQS_QUEUE)['QueueUrl']
        response = sqs.get_queue_attributes(
            QueueUrl=queue_url,
            AttributeNames=['ApproximateNumberOfMessages', 'ApproximateNumberOfMessagesNotVisible']
        )
        attributes = response['Attributes']
        return jsonify({
            'queue_name': SQS_QUEUE,
            'messages_available': int(attributes.get('ApproximateNumberOfMessages', 0)),
            'messages_in_flight': int(attributes.get('ApproximateNumberOfMessagesNotVisible', 0)),
            'region': 'eu-west-1',
            'environment': 'Docker'
        })
    except Exception as e:
        logger.error(f"Errore SQS in worker_stats: {e}")
        return jsonify({'error': str(e)}), 500

def process_sqs_messages():
    try:
        queue_url = sqs.get_queue_url(QueueName=SQS_QUEUE)['QueueUrl']
        response = sqs.receive_message(
            QueueUrl=queue_url,
            MaxNumberOfMessages=10,
            WaitTimeSeconds=5
        )
        
        messages = response.get('Messages', [])
        processed_count = 0
        
        for message in messages:
            try:
                body = json.loads(message['Body'])
                save_analytics_to_dynamodb(body)
                sqs.delete_message(QueueUrl=queue_url, ReceiptHandle=message['ReceiptHandle'])
                processed_count += 1
            except Exception as e:
                logger.error(f"Errore elaborazione messaggio: {e}")
                
        return processed_count
        
    except Exception as e:
        logger.error(f"Errore SQS in process_sqs_messages: {e}")
        return 0

def save_analytics_to_dynamodb(event_data):
    try:
        table = dynamodb.Table(ANALYTICS_TABLE)
        event = {
            'eventId': event_data.get('eventId'),
            'userId': event_data['userId'],
            'eventType': event_data['eventType'],
            'data': event_data['data'],
            'timestamp': event_data.get('timestamp', datetime.now().isoformat()),
            'ttl': int((datetime.now() + timedelta(days=30)).timestamp())
        }
        table.put_item(Item=event)
        logger.info(f"Evento salvato: {event_data['eventType']}")
    except Exception as e:
        logger.error(f"Errore salvataggio DynamoDB: {e}")
